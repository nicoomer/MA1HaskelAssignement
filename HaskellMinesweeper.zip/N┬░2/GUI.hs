
module GUI (mineSweeperOptions) where

-- Import several things from MineSweeper
import MineSweeper

--Data.Map does not expose constructors for “Map”
import Data.Map (Map)
import Data.List ((\\))
import Data.IORef (IORef, newIORef, readIORef, writeIORef)
import qualified Data.Map as M (member, lookup, fromList, size, toList)

-- Import several things from Graphics.UI.Gtk
import Graphics.UI.Gtk
import Graphics.UI.Gtk.Gdk.Events as Ev (eventSent, eventButton, MouseButton(..))

{- Given a Maybe (Int, Int) tuple and a button, returns 
the (Int, Int) value of the button's position -}
retrieveMaybeValue :: ButtonClass b => Maybe (Int, Int) -> b -> (Int, Int)
retrieveMaybeValue (Just position) b = position

{- Given a Position and a board, create and 
returns a button for the given position -}
createButton :: MyBoard -> Position -> IO Button
createButton board position
  | (flaggedButton position board) = do 
    button <- buttonNewWithLabel "F"
    return button

  | otherwise = do
    button <- buttonNew
    return button

{- Destroy a given button in the GUI -}
destroyButton :: (ButtonClass b, Ord b) => b -> IO ()
destroyButton button = widgetDestroy button

{- Destroy all buttons of a map -}
destroyButtonInMap :: (ButtonClass b, Ord b) => Map b (Int, Int) -> IO ()
destroyButtonInMap buttonPositionMap = do 

  let listOfTuples = M.toList buttonPositionMap
  let buttonList = takeFirstInTuple listOfTuples
  sequence_ (map (destroyButton) buttonList)

{- Add or remove a flag label on a button in the GUI,
update the counter "flagLabel" accordingly -}
buttonSwitch :: ButtonClass b => Window -> Label -> b -> IO ()
buttonSwitch window flagLabel button = do

  txt <- buttonGetLabel button

  if (txt == "F") -- If we have a flag label, unflag it
    then do 

      let newtxt = ""
      updateFlagLabel window flagLabel (+)
      buttonSetLabel button newtxt

  else do -- vice-versa

    let newtxt = "F"
    updateFlagLabel window flagLabel (-)
    buttonSetLabel button newtxt

{- Attach a button at given positon to a given table -}
attachButton :: Table -> Button -> (Int, Int) -> IO ()
attachButton table button (y, x) = tableAttachDefaults table button (y - 1) y (x - 1) x

{- Given a Position and a String create and 
returns a label for the given position -}
createLabel :: MyBoard -> Position -> IO Label
createLabel board (x, y) = do

  let message = adjacentMines board (x, y)
  label <- labelNew (Just message)
  colorLabel message label

  return label

{- Colors a label according to the text on it -}
colorLabel :: String -> Label -> IO ()
colorLabel "1" label = widgetModifyFg label StateNormal (Color 0 0 20000)
colorLabel "2" label = widgetModifyFg label StateNormal (Color 0 20000 0)
colorLabel "3" label = widgetModifyFg label StateNormal (Color 65535 0 0)
colorLabel "4" label = widgetModifyFg label StateNormal (Color 0 0 65535)
colorLabel "5" label = widgetModifyFg label StateNormal (Color 20000 10000 0)
colorLabel "6" label = widgetModifyFg label StateNormal (Color 0 40000 40000)
colorLabel "7" label = widgetModifyFg label StateNormal (Color 40000 0 40000)
colorLabel "8" label = widgetModifyFg label StateNormal (Color 30000 30000 30000)
colorLabel txt label = widgetModifyFg label StateNormal (Color 0 0 0)

{- Attach a label with String message at given positon to a given table -}
attachLabel :: Window -> Table -> Label -> (Int, Int) -> IO ()
attachLabel window table label (y, x) = do

  tableAttachDefaults table label (y - 1) y (x - 1) x
  widgetShowAll window

{- Decrement or Increment the value of a 
label accroding to the given operation -}
updateFlagLabel :: Window -> Label -> (Int -> Int -> Int) -> IO () 
updateFlagLabel window flagLabel operation = do 

  number <- labelGetLabel flagLabel
  labelSetText flagLabel (show (((read number)::Int) `operation` 1))
  widgetShowAll window

{- Increment the value of the timer label, stops if 
game is won OR lost and displays the Game Over Window -}
updateTimer :: IORef MyBoard -> Label -> IO Bool 
updateTimer boardRef timerLabel = do 

  board <- readIORef boardRef
  number <- labelGetLabel timerLabel

  -- If the game is won OR lost, stop the timer
  if (won board) 
     then do 

       infoGUI "Game Over" "Congratulations, you won =D" ((read number)::Int) "complete the game !"
       return False

  else if (lost board) 
     then do 

       infoGUI "Game Over" "Sorry, you lost :(" ((read number)::Int) "fail miserably !"
       return False

  else do -- Otherwise Increment the timer

     labelSetText timerLabel (show (((read number)::Int) + 1))
     return True

{- Entry point of program, display the MineSweeper 
Options GUI, sends data to myMainGUI -}
mineSweeperOptions :: IO ()
mineSweeperOptions = do

     initGUI
     window <- windowNew
     set window [windowTitle := "MineSweeper Options", containerBorderWidth := 10]

     vb <- vBoxNew False 0
     containerAdd window vb

     hb <- hBoxNew True 0
     boxPackStart vb hb PackNatural 0

     seedLabel <- labelNew (Just "Enter a seed - Example : 42")
     boxPackStart vb seedLabel PackNatural 0
     seedTextField <- entryNew
     boxPackStart vb seedTextField PackNatural 1

     widthLabel <- labelNew (Just "Enter the width of the board")
     boxPackStart vb widthLabel PackNatural 2
     widthTextField <- entryNew
     boxPackStart vb widthTextField PackNatural 3
     
     heightLabel <- labelNew (Just "Enter the height of the board")
     boxPackStart vb heightLabel PackNatural 4
     heightTextField <- entryNew
     boxPackStart vb heightTextField PackNatural 5

     firstClickLabel <- labelNew (Just "First click - Example : (column N°, row N°)")
     boxPackStart vb firstClickLabel PackNatural 6
     firstClickTextField <- entryNew
     boxPackStart vb firstClickTextField PackNatural 7

     okButton <- buttonNewFromStock stockOk
     boxPackStart vb okButton PackNatural 8

     onClicked okButton (myMainGUI seedTextField widthTextField heightTextField firstClickTextField)

     widgetShowAll window
     onDestroy window mainQuit
     mainGUI

{- Main window of the MineSweeper, takes the 4 parameters entered in the Options,
create a new board game and displays the clickable grid -}
myMainGUI :: Entry -> Entry -> Entry -> Entry -> IO ()
myMainGUI seedTextField widthTextField heightTextField firstClickTextField = do

  initGUI
  window <- windowNew
  set window [ windowTitle := "MineSweeper", windowDefaultWidth := 350, windowDefaultHeight := 400]

  mb <- vBoxNew False 0
  containerAdd window mb

  -- Retrieve the entries as IO String
  seed <- entryGetText seedTextField :: IO String
  width <- entryGetText widthTextField :: IO String
  height <- entryGetText heightTextField :: IO String
  firstClick <- entryGetText firstClickTextField :: IO String

  let newBoard = initialize (read seed::Int) ((read width::Int), (read height::Int)) (read firstClick::(Int, Int)) :: MyBoard
  boardRef <- newIORef newBoard
  
  if (M.member (read firstClick::(Int, Int)) (getMinesMap newBoard))
     then (infoGUI "Out of Luck" "Sorry, your first click was a bomb !\nYou can change your first click or the seed in the options !" 0 "")

  else do
     
     timeLabel <- labelNew (Just "Timer : ")
     boxPackStart mb timeLabel PackNatural 1
     timer <- labelNew (Just "0")
     boxPackStart mb timer PackNatural 2
     timeoutAdd (updateTimer boardRef timer) 1000
   
     flagLeftLabel <- labelNew (Just "Flag left : ")
     boxPackStart mb flagLeftLabel PackNatural 3
     flagLabel <- labelNew (Just (show(M.size (getMinesMap newBoard))))
     boxPackStart mb flagLabel PackNatural 4
   
     resetButton <- buttonNewFromStock stockRefresh
     boxPackStart mb resetButton PackNatural 0
   
     separator <- hSeparatorNew
     boxPackStart mb separator PackNatural 7
     
     scrwin <- scrolledWindowNew Nothing Nothing
     boxPackStart mb scrwin PackGrow 0
   
     table <- tableNew (read height::Int) (read width::Int) True
     scrolledWindowAddWithViewport scrwin table
   
     updateGUI window table flagLabel boardRef

     onClicked resetButton $ do 

      (widgetDestroy window)
      (myMainGUI seedTextField widthTextField heightTextField firstClickTextField)
   
     widgetShowAll window
     onDestroy window mainQuit
     mainGUI

{- Main Right/Left Click Event Handler, execute the old flag and click functions on the board -}
actionButton :: (ButtonClass b, Ord b) => Window -> Table -> Label -> IORef MyBoard -> Map b (Int, Int) -> b -> IO (ConnectId b)
actionButton window table flagLabel boardRef buttonPositionMap button = 
  onButtonPress button (\x -> if (Ev.eventButton x) == Ev.RightButton

    then do -- Right Click for orginal flag function

      position <- return (retrieveMaybeValue (M.lookup button buttonPositionMap) button)
      board <- readIORef boardRef
      newBoard <- return (flag position board)

      writeIORef boardRef newBoard -- Update the IORef
      buttonSwitch window flagLabel button -- (Un)Flag the corresponding button

      return (Ev.eventSent x)

    else do -- Left Click for orginal click function

      position <- return (retrieveMaybeValue (M.lookup button buttonPositionMap) button)
      board <- readIORef boardRef
      newBoard <- return (click position board)

      writeIORef boardRef newBoard -- Update the IORef 
      destroyButtonInMap buttonPositionMap -- Destroy all Buttons 
      checkWinLoss window table flagLabel boardRef

      return (Ev.eventSent x))

{- Keep the synchronisation with the GUI and the game, update myMainGui accordingly -}
updateGUI :: Window -> Table -> Label -> IORef MyBoard -> IO [ConnectId Button]
updateGUI window table flagLabel boardRef = do 

  board <- readIORef boardRef

  let buttonPositions = unclickedPositionsList (getMap board)
  -- All the cells that are clicked are labels
  let labelPositions = getAllPositions (getBounds board) \\ buttonPositions
   
  -- Create GUI Labels and Buttons according to their Positions
  labelList <- sequence (map (createLabel board) labelPositions)
  buttonList <- sequence (map (createButton board) buttonPositions)
   
  let buttonPositionMap = (M.fromList (zip buttonList buttonPositions))
   
  -- Attach Labels and Buttons to Table
  sequence_ (zipWith (attachLabel window table) labelList labelPositions)
  sequence_ (zipWith (attachButton table) buttonList buttonPositions)
   
  -- Link every button to their specific action
  sequence (map (actionButton window table flagLabel boardRef buttonPositionMap) buttonList)

{- If a game is Won or Lost : diplay the whole board, otherwise update myMainGui accordingly -}
checkWinLoss :: Window -> Table -> Label -> IORef MyBoard -> IO ()
checkWinLoss window table flagLabel boardRef = do

  board <- readIORef boardRef

  if (won board || lost board)
     then do -- Revealed the whole board in the grid 

       let labelPositions = getAllPositions (getBounds board)
       labelList <- sequence (map (createLabel board) labelPositions)
       sequence_ (zipWith (attachLabel window table) labelList labelPositions)
       widgetShowAll window

  else do -- Usual Updating 

     updateGUI window table flagLabel boardRef
     widgetShowAll window

{- Create a new window with given title and given label in it -}
infoGUI :: String -> String -> Int -> String -> IO ()

{- Window used if the first click is a mine -}
infoGUI title message 0 "" = do 

  initGUI
  window <- windowNew
  set window [ windowTitle := title, windowDefaultWidth := 200, windowDefaultHeight := 25 ]
  
  mb <- vBoxNew False 0
  containerAdd window mb

  messageLabel <- labelNew (Just (message))
  boxPackStart mb messageLabel PackNatural 0

  closeButton <- buttonNewFromStock stockClose
  boxPackStart mb closeButton PackNatural 2

  onClicked closeButton (widgetDestroy window)

  widgetShowAll window
  onDestroy window mainQuit
  mainGUI

{- Window used if the Game is Over -}
infoGUI title message time timeMessage = do 

  initGUI
  window <- windowNew
  set window [ windowTitle := title, windowDefaultWidth := 200, windowDefaultHeight := 25 ]
  
  mb <- vBoxNew False 0
  containerAdd window mb

  messageLabel <- labelNew (Just (message))
  boxPackStart mb messageLabel PackNatural 0

  timeLabel <- labelNew (Just ("It took you " ++ (show time) ++ " seconds to " ++ timeMessage))
  boxPackStart mb timeLabel PackNatural 1

  closeButton <- buttonNewFromStock stockClose
  boxPackStart mb closeButton PackNatural 2

  onClicked closeButton (widgetDestroy window)

  widgetShowAll window
  onDestroy window mainQuit
  mainGUI
