import MineSweeper (MyBoard, Board(initialize, getMinesMap), Position, loop)
import GUI (mineSweeperOptions)

import Data.Char (toUpper)
import qualified Data.Map as M (member, size)

{- Display the number of mines and if the first click was a bomb,
in Main.hs otherwise no acces to the top function -}
info :: Board b => b -> Position -> IO ()
info board firstClick = do 

  putStr "\nNumber of Mines : "
  putStrLn $ show (M.size (getMinesMap board))

  if (M.member firstClick (getMinesMap board))
    then do 

      putStrLn "\nSorry, your first click was a bomb !\nYou can change your first click or the seed in the options !"
      top "C" (initialize :: Int -> (Int, Int) -> Position -> MyBoard)

  else
    putStrLn "\nFirst Click went fine, Good Luck !\n"

{- High-Order Function to launch either the Console Version (with 
initialize) or the GUI version (with the MineSweeper Options) -}
top :: Board b => String -> (Int -> (Int, Int) -> Position -> b) -> IO ()

{- Launch the Console Version -}
top "C" cinit = do 

  putStrLn "\nEnter a seed - Example : 42"
  seed <- readLn 
  putStrLn "\nEnter the width of the board"
  width <- readLn
  putStrLn "\nEnter the height of the board"
  height <- readLn
  putStrLn "\nFirst click - Example : (column N°, row N°)"
  firstClick <- readLn
  
  if (width <= 0 || height <= 0) 
      then do 

        putStrLn "\nThe data you entered was invalid, please try again" 
        top "C" (initialize :: Int -> (Int, Int) -> Position -> MyBoard)
  
  else do

      let newBoard = cinit seed (width, height) firstClick
      info newBoard firstClick

      if (not (M.member firstClick (getMinesMap newBoard)))
        then loop $ newBoard

      else
        return ()

{- Launch the Graphical Version -}
top "G" cinit = putStrLn "\nThe Graphical Interface is opening, please wait..." >> mineSweeperOptions 

{- Invalid parameters -}
top _ cinit = putStrLn "\nThe data you entered was invalid, please try again" >> main

{- Main -}
main :: IO ()
main = do 

  putStrLn "\nWhich Version do you want to play ? \nThe Console Version (C) or the GUI version (G) ?"
  choice <- getLine

  top (map toUpper choice) (initialize :: Int -> (Int, Int) -> Position -> MyBoard)